import wave
import numpy as np
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog
import os

# ==========================================
# 第一部分：自研算法工具库 (底层实现)
# ==========================================

def get_hamming_window(window_len):
    #手动实现汉明窗公式: w(n) = 0.54 - 0.46 * cos(2*pi*n / (N-1)) [1]
    n = np.arange(window_len)
    window = 0.54 - 0.46 * np.cos(2 * np.pi * n / (window_len - 1))
    return window

def enframe(signal, frame_len, frame_shift):
    #分帧与加窗处理 [1]#
    signal_len = len(signal)
    # 计算总帧数
    num_frames = int(np.ceil((signal_len - frame_len) / frame_shift)) + 1
    # 补零以确保完整分帧
    pad_len = (num_frames - 1) * frame_shift + frame_len
    padded_signal = np.concatenate((signal, np.zeros(pad_len - signal_len)))
    
    # 构造帧矩阵
    indices = np.tile(np.arange(0, frame_len), (num_frames, 1)) + \
              np.tile(np.arange(0, num_frames * frame_shift, frame_shift), (frame_len, 1)).T
    frames = padded_signal[indices.astype(np.int32)]
    
    # 应用汉明窗
    window = get_hamming_window(frame_len)
    return frames * window

def calc_short_time_energy(frames):
    #计算短时能量: En = sum(x(m)^2) [2, 3]
    return np.sum(frames**2, axis=1)

def calc_short_time_zcr(frames):
    #计算短时平均过零率: 统计相邻采样点符号变化 [3, 4]
    num_frames, frame_len = frames.shape
    zcr = np.zeros(num_frames)
    for i in range(num_frames):
        frame = frames[i]
        count = 0
        for j in range(1, frame_len):
            if frame[j] * frame[j-1] < 0:
                count += 1
        zcr[i] = count
    return zcr

# ==========================================
# 第二部分：任务主逻辑 (I/O 与 检测算法)
# ==========================================

def load_wav_with_wave(filename):
    #使用 Python 标准库 wave 读取音频，不产生第三方依赖 [6]
    with wave.open(filename, 'rb') as wf:
        fs = wf.getparams().framerate
        n_frames = wf.getparams().nframes
        str_data = wf.readframes(n_frames)
        #转换为 16 位整数并归一化到 [-1, 1]
        wave_data = np.frombuffer(str_data, dtype=np.int16)
        wave_data = wave_data.astype(np.float32) / 32768.0
    return fs, wave_data

def endpoint_detection(energy, zcr):
 
    #双门限前端检测算法 [7]
    #步骤：利用 ITU 寻找有声段，利用 ITL 和 IZCT 修正起始点

    # 1. 自动设定门限 (基于前10帧环境噪声)
    noise_energy = np.mean(energy[:10])
    noise_zcr = np.mean(zcr[:10])
    
    ITU = noise_energy * 12.0   # 高能量门限
    ITL = noise_energy * 6.0   # 低能量门限
    IZCT = noise_zcr * 4.5     # 过零率门限
    
    segments = []
    in_voiced = False
    temp_start = 0
    
    #2.状态机：利用高低能量门限初步搜索 [7]
    for i in range(len(energy)):
        if not in_voiced and energy[i] > ITU:
            in_voiced = True
            temp_start = i
        elif in_voiced and energy[i] < ITL:
            in_voiced = False
            segments.append([temp_start, i])
            
    return segments, [ITU, ITL, IZCT]

def main():
    # ==========================================
    # 窗口化文件选择逻辑 [追加要求实现]
    # ==========================================
    # 创建一个隐藏的 Tkinter 根窗口
    root = tk.Tk()
    root.withdraw() 

    # 获取当前 py 文件所在的目录，作为弹窗的默认打开位置 [1, 3]
    current_dir = os.getcwd()
    
    print("正在等待用户选择音频文件...")
    
    # 弹出系统标准文件选择对话框
    # filetypes 限制只能选择 wav 文件，避免读取错误 [2]
    audio_file = filedialog.askopenfilename(
        initialdir=current_dir, 
        title="请选择一个语音文件 (需包含静音段)",
        filetypes=(("WAV files", "*.wav"), ("All files", "*.*"))
    )

    # 检查用户是否取消了选择
    if not audio_file:
        print("未选择任何文件，程序即将退出。")
        return

    # ==========================================
    # 后续任务处理逻辑 [任务 1]
    # ==========================================
    try:
        # 使用自研 load_wav_with_wave 函数读取数据 [2, 4]
        fs, data = load_wav_with_wave(audio_file)
        file_name = os.path.basename(audio_file)
        print(f"成功读取文件: {file_name} | 采样率: {fs}")
    except Exception as e:
        print(f"读取失败: {e}。请确保文件是标准的 PCM 格式 WAV 文件。")
        return

    # 1. 预处理与特征提取 (典型值：25ms 帧长, 10ms 帧移) [5]
    frame_len = int(0.025 * fs)
    frame_shift = int(0.01 * fs)
    frames = enframe(data, frame_len, frame_shift)
    
    energy = calc_short_time_energy(frames)
    zcr = calc_short_time_zcr(frames)

    # 2. 执行双门限检测算法 [6]
    segments, thresholds = endpoint_detection(energy, zcr)
    itu, itl, izct = thresholds

    # 输出检测结果分析 [7]
    print(f"检测完成！在 {len(data)/fs:.2f}s 信号中发现 {len(segments)} 个语音段:")
    for i, (start, end) in enumerate(segments):
        # 将帧索引代换回采样点索引，并换算为时间 [8]
        duration = (end - start) * frame_shift / fs
        print(f"  语音段 {i+1}: 起始点 {start*frame_shift}, 结束点 {end*frame_shift} (时长: {duration:.3f}秒)")

    # 3. 绘图展示 (Matplotlib) [2, 9]
    plt.figure(figsize=(10, 8))
    
    # 子图 1: 原始波形与红绿标注线
    plt.subplot(3, 1, 1)
    plt.plot(data, color='silver', alpha=0.8)
    for i, (start, end) in enumerate(segments):
        # 红色虚线表示开始点，绿色虚线表示结束点
        plt.axvline(x=start * frame_shift, color='red', linestyle='--')
        plt.axvline(x=end * frame_shift, color='green', linestyle='--')
    plt.title(f"Speech Waveform & Detected Endpoints ({file_name})")
    plt.ylabel("Amplitude")

    # 子图 2: 短时能量与 ITU/ITL 门限 [6]
    plt.subplot(3, 1, 2)
    plt.plot(energy, color='blue', label='Short-time Energy')
    plt.axhline(y=itu, color='red', linestyle=':', label=f'ITU={itu:.2e}')
    plt.axhline(y=itl, color='orange', linestyle=':', label=f'ITL={itl:.2e}')
    plt.ylabel("Energy")
    plt.legend(loc='upper right')

    # 子图 3: 短时过零率与 IZCT 门限 [6]
    plt.subplot(3, 1, 3)
    plt.plot(zcr, color='darkcyan', label='ZCR')
    plt.axhline(y=izct, color='magenta', linestyle=':', label=f'IZCT={izct:.1f}')
    plt.ylabel("Zero Crossing Rate")
    plt.xlabel("Frame Index")
    plt.legend(loc='upper right')

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()